package main;

import menu.Menu_21130814_MonjeRojas;


/**
 * Clase Main
 * Ejecuta {@link menu.Menu_21130814_MonjeRojas}
 */
public class Main_21130814_MonjeRojas {
    /**
     * Método Main
     * Utiliza Menu para inicializar programa
     * @param args no se utiliza
     */
    public static void main(String[] args) {
        Menu_21130814_MonjeRojas menu = new Menu_21130814_MonjeRojas();
        menu.run();
    }
}
